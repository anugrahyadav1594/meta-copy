# Member 1 Viva Cheatsheet

## What exactly did you build?

I built the canonical normalized relational database for the project in PostgreSQL.

## Why PostgreSQL?

We need a relational database for structured entities, relationships, constraints and transactions. PostgreSQL also gives us strong indexing and query-analysis tools that later members can benchmark and optimize.

## Why did you split users and profiles?

Because account data and profile data represent different responsibilities. It also avoids repeating profile values in every post.

## What is a primary key?

A primary key uniquely identifies a row.

Example:

```text
users.user_id
posts.post_id
```

## What is a foreign key?

A foreign key connects a row to a parent row in another table.

Example:

```text
posts.user_id → users.user_id
```

## Why use composite keys?

For likes:

```text
(user_id, post_id)
```

The pair uniquely identifies one user's like on one post.

It also prevents duplicate likes.

## What is normalization?

Normalization is the process of organizing data into related tables to reduce unnecessary redundancy and avoid insert, update and delete anomalies.

## What is 1NF?

Atomic values; no repeating groups in a single field.

## What is 2NF?

After 1NF, remove partial dependencies from composite-key tables.

## What is 3NF?

After 2NF, remove transitive dependencies so non-key attributes depend on the key and not on another non-key attribute.

## Give a 3NF example from this project.

A post should not store username and email.

Instead:

```text
posts.user_id
        ↓
users.user_id

users store email.
profiles store username.
posts store post data.
```

## Why not just denormalize everything?

Because denormalization increases redundancy and makes writes/updates more complicated.

Our project intentionally starts normalized so we can later compare it with optimized designs.

## What is the role of indexes?

Indexes help PostgreSQL locate rows faster for common queries.

Example:

```text
posts(user_id, created_at)
```

helps when retrieving a user's recent posts.

## Are indexes part of normalization?

No.

Normalization is about data structure and dependencies.

Indexes are mainly a performance mechanism.

## What will other teammates do with your schema?

They will build optimizations around it:

```text
My normalized DB
      ↓
query optimization
      ↓
denormalized views
      ↓
sharding
      ↓
replication
      ↓
cache
      ↓
distributed services
```

The relational schema remains the source of truth.

---

# One sentence to remember

> "I designed the clean source-of-truth relational model first; the rest of the team optimizes how that data is stored and accessed at scale."
